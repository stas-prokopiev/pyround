"""Initializer of package"""
# Standard library imports

# Third party imports

# Local imports
from .main import pyround

round2 = pyround


__all__ = ["pyround", "round2"]
